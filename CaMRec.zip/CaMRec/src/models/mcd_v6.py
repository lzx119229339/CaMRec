import os
import numpy as np
import scipy.sparse as sp
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.utils import remove_self_loops, add_self_loops, degree
import torch_geometric
from diffusion.diffusion_v1 import diffusion
from utils.graphmlp import GMLP
from common.abstract_recommender import GeneralRecommender
from common.loss import BPRLoss, EmbLoss
from common.init import xavier_uniform_initialization
import torch
import torch.nn as nn
import torch.nn.functional as F
import copy
from utils.utils import * 
from utils.fusion import CrossModalAttention 
from utils.loss import * 

class MCD_V6(GeneralRecommender):
    def __init__(self, config, dataset):
        super(MCD_V6, self).__init__(config, dataset)

        num_user = self.n_users
        num_item = self.n_items

        dim_x = config['embedding_size']
        self.embedding_size = config['feat_embed_dim']
        self.feat_embed_dim = config['feat_embed_dim']
        self.n_layers = config['n_layers']
        self.knn_k = config['knn_k']
        self.mm_image_weight = config['mm_image_weight']
        self.dropout = config['dropout']
        self.reg_weight = config['reg_weight']
        self.temp = config['temp']
        dataset_path = os.path.abspath(config['data_path'] + config['dataset'])
        self.image_knn_k = config['image_knn_k']
        self.text_knn_k = config['text_knn_k']
        self.diff_weight = config['diff_weight']
        self.steps = config['timesteps']
        

        self.num_user = num_user
        self.num_item = num_item
        self.k = 40
        self.aggr_mode = 'add'
        self.dataset = dataset
        

        
        self.drop_rate = 0.1
        self.v_rep = None
        self.t_rep = None
        self.v_preference = None

        
        
        self.id_preference = None
        self.dim_latent = 64
        self.dim_feat = 128
        self.mm_adj = None
        self.t_prefer = nn.Parameter(nn.init.xavier_normal_(torch.tensor(
                np.random.randn(self.n_users, self.dim_latent), dtype=torch.float32, requires_grad=True),
                gain=1).to(self.device))
        self.v_prefer= nn.Parameter(nn.init.xavier_normal_(torch.tensor(
                np.random.randn(self.n_users, self.dim_latent), dtype=torch.float32, requires_grad=True),
                gain=1).to(self.device))



        if self.v_feat is not None:
            self.image_trs = nn.Linear(self.v_feat.shape[1], self.feat_embed_dim)
            self.image_unique = nn.Linear(self.v_feat.shape[1],self.feat_embed_dim)
        if self.t_feat is not None:
            self.text_trs = nn.Linear(self.t_feat.shape[1], self.feat_embed_dim)
            self.text_unique = nn.Linear(self.t_feat.shape[1], self.feat_embed_dim)
        train_interactions = dataset.inter_matrix(form='coo').astype(np.float32)
        edge_index = self.pack_edge_index(train_interactions)
        self.edge_index = torch.tensor(edge_index, dtype=torch.long).t().contiguous().to(self.device)
        self.edge_index = torch.cat((self.edge_index, self.edge_index[[1, 0]]), dim=1)
       
  
        self.gcn = GCN(self.dataset,num_user, num_item, dim_x, self.aggr_mode, dim_latent=64,
                             device=self.device)



        
        self.sparse = True
    
        image_adj_file = os.path.join(dataset_path, 'image_adj_{}_{}.pt'.format(self.image_knn_k, self.sparse))
        text_adj_file = os.path.join(dataset_path, 'text_adj_{}_{}.pt'.format(self.text_knn_k, self.sparse))
        if os.path.exists(image_adj_file):
                image_adj = torch.load(image_adj_file)
        else:
            image_adj = build_sim(self.v_feat.detach())
            image_adj = build_knn_normalized_graph(image_adj, topk=self.image_knn_k, is_sparse=self.sparse,
                                                    norm_type='sym')
            torch.save(image_adj, image_adj_file)
        self.image_original_adj = image_adj.to(self.device) 
        
        if os.path.exists(text_adj_file):
                text_adj = torch.load(text_adj_file)
        else:
            text_adj = build_sim(self.t_feat.detach())
            text_adj = build_knn_normalized_graph(text_adj, topk=self.text_knn_k, is_sparse=self.sparse, norm_type='sym')
            torch.save(text_adj, text_adj_file)
        self.text_original_adj = text_adj.to(self.device)
        self.fused_adj = max_pool_fusion(self.image_original_adj,self.text_original_adj,device=self.device)

        self.item_id_embedding = nn.Embedding(self.n_items, self.embedding_size)

        nn.init.xavier_uniform_(self.item_id_embedding.weight)

        self.diffusion_t = diffusion(config)
        self.diffusion_v = diffusion(config)
        
        
        self.w1 = config['w1']
        self.w2 = config['w2']
        self.sample_tv = None
        self.sample_vt = None
  
  

    def drop_edges(self,edge_index, drop_rate=0.2):
        """
        随机丢弃一定比例的边
        :param edge_index: [2, num_edges] 的张量，表示图的边
        :param drop_rate: 丢弃边的比例
        :return: 新的 edge_index
        """
        num_edges = edge_index.size(1)  # 获取边的数量
        keep_prob = 1 - drop_rate  # 需要保留的比例

        mask = torch.rand(num_edges, device=edge_index.device) < keep_prob

        # 只保留 mask 选中的边
        edge_index = edge_index[:, mask]
        return edge_index
    
    def get_adj_mat(self):
        adj_mat = sp.dok_matrix((self.n_users + self.n_items, self.n_users + self.n_items), dtype=np.float32)
        adj_mat = adj_mat.tolil()
        R = self.interaction_matrix.tolil()

        adj_mat[:self.n_users, self.n_users:] = R
        adj_mat[self.n_users:, :self.n_users] = R.T
        adj_mat = adj_mat.todok()

        def normalized_adj_single(adj):
            rowsum = np.array(adj.sum(1))
            rowsum[rowsum == 0] = 1  # 避免除0错误
            
            d_inv = np.power(rowsum, -0.5).flatten()
            d_inv[np.isinf(d_inv)] = 0.
            d_mat_inv = sp.diags(d_inv)

            norm_adj = d_mat_inv.dot(adj_mat)
            norm_adj = norm_adj.dot(d_mat_inv)
            return norm_adj.tocoo()

        norm_adj_mat = normalized_adj_single(adj_mat)
        norm_adj_mat = norm_adj_mat.tolil()
        self.R = norm_adj_mat[:self.n_users, self.n_users:]
        return norm_adj_mat.tocsr()

    def sparse_mx_to_torch_sparse_tensor(self, sparse_mx):
        """Convert a scipy sparse matrix to a torch sparse tensor."""
        sparse_mx = sparse_mx.tocoo().astype(np.float32)
        indices = torch.from_numpy(np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
        values = torch.from_numpy(sparse_mx.data)
        shape = torch.Size(sparse_mx.shape)
        return torch.sparse.FloatTensor(indices, values, shape)
    
    def pack_item_edge_index(self):
        edge_src = [] 
        edge_dst = [] 
        edge_weights = []
        for item_id,(nbr_list,w_list) in self.item_graph_dict.items():
            for nbr_id,w in zip(nbr_list,w_list):
                edge_src.append(item_id)
                edge_dst.append(nbr_id)
                edge_weights.append(w)
                edge_src.append(nbr_id)
                edge_dst.append(item_id)
                edge_weights.append(w)
        edge_index = torch.tensor([edge_src, edge_dst], dtype=torch.long)
        edge_weight = torch.tensor(edge_weights, dtype=torch.float)

        return edge_index, edge_weight

    def get_knn_adj_mat(self, mm_embeddings):
        context_norm = mm_embeddings.div(torch.norm(mm_embeddings, p=2, dim=-1, keepdim=True))
        sim = torch.mm(context_norm, context_norm.transpose(1, 0))
        _, knn_ind = torch.topk(sim, self.knn_k, dim=-1)
        adj_size = sim.size()
        del sim
        # construct sparse adj
        indices0 = torch.arange(knn_ind.shape[0]).to(self.device)
        indices0 = torch.unsqueeze(indices0, 1)
        indices0 = indices0.expand(-1, self.knn_k)
        indices = torch.stack((torch.flatten(indices0), torch.flatten(knn_ind)), 0)
        # norm
        return indices, self.compute_normalized_laplacian(indices, adj_size)

    def compute_normalized_laplacian(self, indices, adj_size):
        adj = torch.sparse.FloatTensor(indices, torch.ones_like(indices[0]), adj_size)
        row_sum = 1e-7 + torch.sparse.sum(adj, -1).to_dense()
        r_inv_sqrt = torch.pow(row_sum, -0.5)
        rows_inv_sqrt = r_inv_sqrt[indices[0]]
        cols_inv_sqrt = r_inv_sqrt[indices[1]]
        values = rows_inv_sqrt * cols_inv_sqrt
        return torch.sparse.FloatTensor(indices, values, adj_size)

    def pre_epoch_processing(self):
        pass

    def pack_edge_index(self, inter_mat):
        rows = inter_mat.row
        cols = inter_mat.col + self.n_users
        return np.column_stack((rows, cols))

    def InfoNCE(self, view1, view2, index,temp=0.2):
    
        view1 = view1[index]
        view2 = view2[index]
     
        view1 = F.normalize(view1, dim=1)
        view2 = F.normalize(view2, dim=1)

        pos_score = (view1 * view2).sum(dim=-1)
        pos_score = torch.exp(pos_score / temp)
        ttl_score = torch.matmul(view1, view2.transpose(0, 1))
        ttl_score = torch.exp(ttl_score / temp).sum(dim=1)
        cl_loss = -torch.log(pos_score / ttl_score)
        return torch.mean(cl_loss)




    def forward(self,t_feat,v_feat,t_generate=None,v_generate=None):
        
      


 

        self.t_embedding = self.w1 * v_generate + (1-self.w1)*t_feat
        self.v_embedding = self.w2 * t_generate + (1-self.w2)*v_feat
      
        self.t_rep = self.gcn(self.edge_index,self.t_prefer,self.t_embedding)
        self.v_rep = self.gcn(self.edge_index,self.v_prefer,self.v_embedding)


        self.result_embed = torch.cat((self.t_rep,self.v_rep),dim=1)
        return None


    def buildItemGraph(self, h):

        h = torch.sparse.mm(self.mm_adj, h)
        return h
   

    def BPR(self,result_embed):
        user_tensor = result_embed[self.user_nodes]
        pos_item_tensor = result_embed[self.pos_item_nodes]
        neg_item_tensor = result_embed[self.neg_item_nodes]

        pos_scores = torch.sum(user_tensor * pos_item_tensor, dim=1)
        neg_scores = torch.sum(user_tensor * neg_item_tensor, dim=1)
        loss_rec = -torch.mean(torch.log2(torch.sigmoid(pos_scores - neg_scores)))
        return loss_rec
    
    
    def calculate_loss(self, interaction):
        self.user_nodes, self.pos_item_nodes, self.neg_item_nodes = interaction[0], interaction[1], interaction[2]

        self.pos_item = self.pos_item_nodes.clone() 
        self.neg_item = self.neg_item_nodes.clone()
        
        
        self.pos_item_nodes += self.n_users
        self.neg_item_nodes += self.n_users
        
        t_feat_ori = self.text_trs(self.t_feat)
        v_feat_ori = self.image_trs(self.v_feat)
        v_feat = torch.sparse.mm(self.image_original_adj,v_feat_ori)
        t_feat = torch.sparse.mm(self.text_original_adj,t_feat_ori)
        id_feat = torch.sparse.mm(self.fused_adj,self.item_id_embedding.weight)
        
        
        t= torch.randint(low=0, high=self.steps, size=(t_feat_ori.shape[0] // 2 + 1,)).to(self.device)
        t = torch.cat([t, self.steps - t - 1], dim=0)[:t_feat_ori.shape[0]]
        
        
        diff_loss1,t_generate = self.diffusion_t.p_losses(t_feat,id_feat,t) ## 用文本生成的图像表征 在图像空间里
        diff_loss2,v_generate = self.diffusion_v.p_losses(v_feat,id_feat,t) ## 用图像生成的文本表征 在文本空间里 
        diff_loss = self.diff_weight*(diff_loss1+diff_loss2)
        
        self.forward(t_feat,v_feat,t_generate,v_generate)
 
        # ssl_loss_text = self.InfoNCE(self.t_rep,self.t_unique,self.user_nodes) + self.InfoNCE(self.t_rep,self.t_unique,self.pos_item_nodes)
        # # ssl_loss_image = self.InfoNCE(self.v_rep,self.v_unique,self.user_nodes) + self.InfoNCE(self.v_rep,self.v_unique,self.pos_item_nodes)
        # ssl_loss_tv = self.InfoNCE(self.t_unique,self.v_unique,self.user_nodes)+ self.InfoNCE(self.t_unique,self.v_unique,self.pos_item_nodes)
        
        # ssl_loss = 0.01 * (ssl_loss_text+ssl_loss_tv)
                
        loss_rec = self.BPR(self.result_embed) 
        

        reg_embedding_loss_v = (self.v_prefer[self.user_nodes] ** 2).mean() if self.v_prefer is not None else 0.0
        reg_embedding_loss_t = (self.t_prefer[self.user_nodes] ** 2).mean() if self.v_prefer is not None else 0.0
        reg_loss = self.reg_weight * (reg_embedding_loss_v+reg_embedding_loss_t) 
  
  
  

        return loss_rec + reg_loss + diff_loss 

    def full_sort_predict(self, interaction):
        t_feat_ori = self.text_trs(self.t_feat)
        v_feat_ori = self.image_trs(self.v_feat)
        v_feat = torch.sparse.mm(self.image_original_adj,v_feat_ori)
        t_feat = torch.sparse.mm(self.text_original_adj,t_feat_ori)
      
        self.forward(t_feat,v_feat,self.sample_t,self.sample_v)
        user_tensor = self.result_embed[:self.n_users]
        item_tensor = self.result_embed[self.n_users:]
        
        temp_user_tensor = user_tensor[interaction[0], :]
        score_matrix = torch.matmul(temp_user_tensor, item_tensor.t())
        return score_matrix
    



    
   
    def sample(self):
  
        t_feat_ori = self.text_trs(self.t_feat)
        v_feat_ori = self.image_trs(self.v_feat)
        v_feat = torch.sparse.mm(self.image_original_adj,v_feat_ori)
        t_feat = torch.sparse.mm(self.text_original_adj,t_feat_ori)
        id_feat = torch.sparse.mm(self.fused_adj,self.item_id_embedding.weight)

        
        t_generate = self.diffusion_t.sample(t_feat,id_feat) 
        v_generate = self.diffusion_v.sample(v_feat,id_feat)
        
        


        self.sample_t = t_generate.detach()
        self.sample_v = v_generate.detach()




        

from sklearn.preprocessing import StandardScaler
class GCN(torch.nn.Module):
    def __init__(self, datasets,num_user, num_item, dim_id, aggr_mode,
                 dim_latent=None, device=None):
        super(GCN, self).__init__()

        self.num_user = num_user
        self.num_item = num_item
        self.datasets = datasets
        self.dim_id = dim_id
        self.dim_feat = dim_latent
        self.dim_latent = dim_latent
        self.aggr_mode = aggr_mode
        self.device = device
        if self.dim_latent:

            self.conv_embed = Base_gcn(self.dim_latent, self.dim_latent, aggr=self.aggr_mode)

        else:
            self.preference = nn.Parameter(nn.init.xavier_normal_(torch.tensor(
                np.random.randn(num_user, self.dim_feat), dtype=torch.float32, requires_grad=True),
                gain=1).to(self.device))
            self.conv_embed = Base_gcn(self.dim_latent, self.dim_latent, aggr=self.aggr_mode)

    def forward(self,edge_index, prefer,feature):
        
        x = torch.cat([prefer,feature],dim=0)
        x = F.normalize(x)
        
        # item -> user  
        h = self.conv_embed(x, edge_index)
        # user MLP 
        
        h_1 = self.conv_embed(h,edge_index)
        x_hat = x + h + h_1 
        return x_hat
  
  

class Base_gcn(MessagePassing):
    def __init__(self, in_channels, out_channels, normalize=True, bias=True, aggr='add', **kwargs):
        super(Base_gcn, self).__init__(aggr=aggr, **kwargs)
        self.aggr = aggr
        self.in_channels = in_channels
        self.out_channels = out_channels

    def forward(self, x, edge_index,size=None):
        if size is None:
            edge_index, _ = remove_self_loops(edge_index)
        x = x.unsqueeze(-1) if x.dim() == 1 else x
        

        return self.propagate(edge_index, size=(x.size(0), x.size(0)), x=x)

    def message(self, x_j, edge_index, size=None):
        if self.aggr == 'add':
            row, col = edge_index
            deg = degree(row, size[0], dtype=x_j.dtype)
            deg_inv_sqrt = deg.pow(-0.5)
            norm = deg_inv_sqrt[row] * deg_inv_sqrt[col]
            
            return norm.view(-1, 1) * x_j
        return x_j

    def update(self, aggr_out):
        return aggr_out

    def __repr(self):
        return '{}({},{})'.format(self.__class__.__name__, self.in_channels, self.out_channels)
    


